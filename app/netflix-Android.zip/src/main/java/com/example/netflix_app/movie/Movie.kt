package com.example.netflix_app.movie

class Movie(
    var id: String = "",
    var title: String = "",
    var duration: String = "",
    var imageUrl: String = "",
    var synopsis: String = ""
)